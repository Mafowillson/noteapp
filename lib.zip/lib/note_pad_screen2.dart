import 'dart:async';
import 'dart:developer';

import 'package:flutter/material.dart';

import 'database/ntdatabase.dart';
import 'model/note.dart';
import 'services/noteServices.dart';

class Notes extends StatefulWidget {
  const Notes({super.key});

  @override
  State<Notes> createState() => _NotesState();
}

class _NotesState extends State<Notes> {
  TextEditingController title = TextEditingController();
  TextEditingController description = TextEditingController();
  List? _list;
  Timer? _time;

  Future getAllNote() async {
    _list = await NoteController().fetchAllNote();
    log(_list.toString());
  }

  @override
  void initState() {
    getAllNote();
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
    title.dispose();
    description.dispose();
  }

  void clearInput() {
    title.clear();
    description.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notes'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Expanded(
          child: ListView(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(DateTime.now().toString()),
                  TextField(
                    controller: title,
                    decoration: const InputDecoration(
                      hintText: 'Tittle',
                      hintStyle: TextStyle(
                        fontSize: 10,
                      ),
                      border: InputBorder.none,
                    ),
                  ),
                  SizedBox(
                    child: TextField(
                      maxLines: null,
                      controller: description,
                      decoration: const InputDecoration(
                        hintText: 'Note something down',
                        hintStyle: TextStyle(
                          fontSize: 10,
                        ),
                        border: InputBorder.none,
                      ),
                    ),
                  ),
                  // ElevatedButton(
                  //   onPressed: () {
                  //     Note noteInfo = Note(
                  //       id: null,
                  //       title: title.text,
                  //       description: description.text,
                  //       created_at: DateTime.now().toString(),
                  //     );

                  //   },

                  // child: const Center(
                  //   child: SizedBox(
                  //     child: Padding(
                  //       padding: EdgeInsets.all(8.0),
                  //       child: Text(
                  //         'Save',
                  //         style: TextStyle(
                  //           fontSize: 20,
                  //           color: Colors.blue,
                  //         ),
                  //       ),
                  //     ),
                  //   ),
                  // ),
                  //child: ,
                  //),
                ],
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.grey,
        child: const Icon(
          Icons.save,
          size: 35,
        ),
        onPressed: () async {
          // Navigator.pop(context, [title.text, description.text]);
          if (title.text.isEmpty || description.text.isEmpty) {
            print("All Field are required");
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                backgroundColor: Colors.red,
                content: Text('All Field are required')));
          } else {
            Note noteInfo = Note(
                id: null,
                title: title.text,
                description: description.text,
                created_at: DateTime.now().toString());

            await NoteController().addNote(noteInfo).then((value) {
              if (value > 0) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                    backgroundColor: Colors.green,
                    content: Text('Note Added Sucessful!')));
                log(_list.toString());
              } else {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                    backgroundColor: Colors.red,
                    content: Text('Fail to add note')));
              }
            });
          }
        },
      ),
      // bottomNavigationBar: BottomAppBar(
      //   elevation: 10,
      //   child: Row(
      //     mainAxisAlignment: MainAxisAlignment.spaceAround,
      //     children: [
      //       Column(
      //         children: [
      //           IconButton(
      //             onPressed: () {},
      //             icon: const Icon(Icons.picture_in_picture),
      //           ),
      //           const Text(
      //             'Albums',
      //             style: TextStyle(
      //               fontSize: 10,
      //             ),
      //           ),
      //         ],
      //       ),
      //       Column(
      //         children: [
      //           IconButton(
      //             onPressed: () {},
      //             icon: const Icon(Icons.mic),
      //           ),
      //           const Text(
      //             'Audio',
      //             style: TextStyle(
      //               fontSize: 10,
      //             ),
      //           ),
      //         ],
      //       ),
      //       Column(
      //         children: [
      //           IconButton(
      //             onPressed: () {},
      //             icon: const Icon(Icons.task_alt),
      //           ),
      //           const Text(
      //             'To-do list',
      //             style: TextStyle(
      //               fontSize: 10,
      //             ),
      //           ),
      //         ],
      //       ),
      //       Column(
      //         children: [
      //           IconButton(
      //             onPressed: () {},
      //             icon: const Icon(
      //               Icons.alarm,
      //             ),
      //           ),
      //           const Text(
      //             'Reminder',
      //             style: TextStyle(
      //               fontSize: 10,
      //             ),
      //           ),
      //         ],
      //       ),
      //     ],
      //   ),
      // ),
    );
  }
}
